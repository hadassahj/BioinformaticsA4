FINICHIU Eduard - Adelin
JERCAU Hadasa - Stefana