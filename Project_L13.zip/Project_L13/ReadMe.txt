Finichiu Eduard Adelin, group 1241EB
Jercau Hadasa-Stefana, group 1241EB
